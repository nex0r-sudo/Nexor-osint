# NEXOR OSINT — GitHub Pages Edition

This package is a static frontend for GitHub Pages. GitHub Pages can serve HTML/CSS/JS over HTTPS, but it does not run the Node/Express backend.

The UI includes:
- NEXOR OSINT branding
- "ujal" micro-label
- dusty-black/grain visual treatment
- responsive mobile/desktop layout
- desktop-only purple cursor trail
- OSINT tool cards and auth UI placeholders

Do NOT put an admin/premium secret in this public repository. A real login/premium system requires a backend.
