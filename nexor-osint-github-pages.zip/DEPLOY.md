# Deploying OSINT Hub

The project is a normal Node.js web server and can be deployed to a Node-compatible host or container platform.

## Recommended baseline
Use Node.js 24 LTS. The official Node download page currently lists v24.21.0 as LTS. 

Set:
- `JWT_SECRET` to a long random secret
- `PORT` if the host provides one

Start command:
`npm start`

For Docker:
`docker build -t osint-hub .`
`docker run -p 3000:3000 -e JWT_SECRET='change-me' osint-hub`

### Important database note
The demo uses SQLite. If your hosting provider has ephemeral storage, replace SQLite with managed PostgreSQL before relying on persistent accounts/history.

### Safety
The included tools operate on public information or local transformations. Do not add leaked-data search, credential testing, private-person lookup, access-control bypass, or doxxing functionality.


### Premium secret
Add an environment variable named `ADMIN_PREMIUM_CODE` in your hosting provider and keep its value private. Do not commit the real code to GitHub or put it in `public/app.js` / `index.html`. Node.js supports environment variables for this kind of server configuration.
