# OSINT Hub

A local-first OSINT dashboard starter with:
- Sign up / log in using bcrypt + JWT
- SQLite user/search history
- DNS records (A, AAAA, MX, NS, TXT)
- Local URL structure analysis
- Reverse DNS
- Best-effort public username checks (GitHub, Reddit, GitLab, Keybase)
- Rate limiting and basic input validation
- Responsive dark UI

## Run
1. Install Node.js 20+.
2. `npm install`
3. Set a strong production secret: `JWT_SECRET="your-long-random-secret"`
4. `npm start`
5. Open `http://localhost:3000`

## Scope
This project intentionally avoids private-data lookup, leaked databases, credential attacks, doxxing, or bypassing access controls. Use it for public information and systems you are authorized to research.

## Production hardening
Use HTTPS, a strong secret, secure cookies/session rotation, CSRF protection if cookies are introduced, a reverse proxy, stricter rate limits, structured logging, and a managed database before public deployment.


## Private Admin Premium
The site includes a server-side premium-code activation. Set `ADMIN_PREMIUM_CODE` in the hosting environment. The real code is never stored in the frontend. A logged-in user can enter the code on the login screen; matching the server secret marks that account as premium.
