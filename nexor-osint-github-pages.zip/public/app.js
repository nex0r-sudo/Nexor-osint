const lines=[...document.querySelectorAll('.cursor-lines i')];
if(matchMedia('(pointer:fine)').matches){
 addEventListener('pointermove',e=>{
   const y=e.clientY, x=e.clientX;
   lines.forEach((el,i)=>{
     const offset=(i-1)*7;
     el.style.top=(y+offset)+'px';
     el.style.width=Math.max(0, innerWidth-x+20)+'px';
     el.style.transform=`rotate(${((x/innerWidth)-.5)*3}deg)`;
   });
 });
}
document.querySelectorAll('.tool button').forEach(b=>b.addEventListener('click',()=>alert('Tool interface ready — connect this card to the NEXOR backend.')));
